<?php
function db_connect()
{
    $ret = array();
    $ret['error_code'] = E_OK;
}
function validate ($category, $value)
{
    return true;
}
?>